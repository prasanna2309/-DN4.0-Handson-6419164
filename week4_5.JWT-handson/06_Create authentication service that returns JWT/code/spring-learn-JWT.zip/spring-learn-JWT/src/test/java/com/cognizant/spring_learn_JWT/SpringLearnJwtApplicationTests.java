package com.cognizant.spring_learn_JWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
